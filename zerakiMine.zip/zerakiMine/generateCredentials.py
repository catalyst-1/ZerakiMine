# all is known about the cred system is that username {admission no@school} code and password is {admission no}
import json

# JUST SETTING NECESSARY VARIABLES#
## prepare args
prep = json.load(open("config.txt"))
print (prep)
minAdmission = prep[0]# smallest admission No ,included , type=number
maxAdmission = prep[1]  # prep['maxAdmission']  # largest admission No ,not included,type=Number
schoolCode = prep[2]  # prep['schoolcode']  # school code used in identification ,type=sting

if minAdmission > maxAdmission:
    tmp = minAdmission
    maxAdmission = minAdmission
    minAdmission = tmp

# generate a  list containing creds
usernames = [f'{str(x)}@{schoolCode}' for x in range(minAdmission, maxAdmission)]
passwords = [x for x in range(minAdmission, maxAdmission)]

# username[i] :
#           [username[i],password[i]]
#
# store credentials in a serialised json format in a file

# creating json object
credentials = {}
noOfAccounts = (maxAdmission - minAdmission) + 1
for i in range(noOfAccounts):
    credentials[usernames[i - 1]] = [usernames[i - 1], passwords[i - 1]]

# storing the files in credentials.txt
json.dump(credentials, open('credentials.txt', 'w+'))

# TO GET DATA FROM FILE
def readCredentials(fileName):
    # READ FILE
    with open(fileName, 'r+') as fd:
        import json
        # DESERIALIZE FILE
        return json.load(fd)
