import random
import json
import requests

schoolCodes = []
sampleSize = 0
absLeast = 0
absMost = 0


def check(username):
    response = requests.post(f'apilearning.zeraki.app/api/v1/check?username={username}',
                             headers={"content-type": "application/json"})
    if response.status_code != 400:
        return True
    else:
        return False


while True:
    try:
        schoolCodes.append(open('rawSchoolGueses', 'a+').readline())
    except:
        break

for code in schoolCodes:
    leastAdmn = 0
    mostAdmn = 0

    for admision in [random.randint(absLeast, absMost) for each in range(sampleSize)]:
        if check(f'{admision}@{code}'):
            print(f'{admision}@{code}')
            if leastAdmn >= admision:
                leastAdmn = admision

            if mostAdmn <= admision:
                mostAdmn = admision

    if check(f'{leastAdmn + 7}@{code}'):
        print(f'{code} from {leastAdmn} to {mostAdmn}')
        log = [code, leastAdmn, mostAdmn]
        json.dump(json.load(open('SchoolCodes.txt', 'a+')).append(log), open('SchoolCodes.txt', 'a+'))
    else:
        pass